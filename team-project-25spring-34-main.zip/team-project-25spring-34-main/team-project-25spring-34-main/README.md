Django project name: IDEframework

Current apps: IDE, group_id, group_learn, lesson, lock_button, login, register, self_learn, ai_assistant

Current htmls: IDE.html, lesson.html, self-learn.html, group-id.html, group-learn.html, login.html, register.html, embed.html

utils: 跨app的通用方法

media folder: media
